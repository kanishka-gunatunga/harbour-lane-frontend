export default function Home() {
  return (
    <div>
      hi
    </div>
  );
}
